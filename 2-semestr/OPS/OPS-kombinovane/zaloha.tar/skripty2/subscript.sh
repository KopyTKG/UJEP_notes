#!/bin/bash

#vnitrni skript, ktery je spousteny dalsim skriptem
echo "Skript zdravi $koho"

exit 0 #pokud je spusteno na stejnem shelu, tak to ukonci beh spustece
